// Main JavaScript file handling game logic
let scene, camera, renderer, soldier, physicsWorld;

init();
animate();

// Initialize scene, camera, renderer
function init() {
    scene = new THREE.Scene();
    camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    renderer = new THREE.WebGLRenderer({ canvas: document.getElementById('gameCanvas') });
    renderer.setSize(window.innerWidth, window.innerHeight);

    // Load soldier model using GLTFLoader
    const loader = new THREE.GLTFLoader();
    loader.load('assets/models/soldier.glb', (gltf) => {
        soldier = gltf.scene;
        soldier.scale.set(1.5, 1.5, 1.5);
        scene.add(soldier);
    });

    // Initialize physics with Ammo.js
    setupPhysicsWorld();
}

// Physics setup
function setupPhysicsWorld() {
    let collisionConfiguration = new Ammo.btDefaultCollisionConfiguration(),
        dispatcher = new Ammo.btCollisionDispatcher(collisionConfiguration),
        broadphase = new Ammo.btDbvtBroadphase(),
        solver = new Ammo.btSequentialImpulseConstraintSolver();
    physicsWorld = new Ammo.btDiscreteDynamicsWorld(dispatcher, broadphase, solver, collisionConfiguration);
    physicsWorld.setGravity(new Ammo.btVector3(0, -9.8, 0));
}

// Game loop
function animate() {
    requestAnimationFrame(animate);
    renderer.render(scene, camera);
    updatePhysics();
}

// Update physics in the loop
function updatePhysics() {
    if (physicsWorld) {
        physicsWorld.stepSimulation(1 / 60);
    }
}
